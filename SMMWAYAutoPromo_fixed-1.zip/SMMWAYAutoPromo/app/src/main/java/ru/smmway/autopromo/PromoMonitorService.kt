package ru.smmway.autopromo

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import org.jsoup.Jsoup
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class PromoMonitorService : Service() {
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private val prefs by lazy { getSharedPreferences("autopromo", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1, notification("Слежу за @smmwayru"))
        executor.scheduleWithFixedDelay({ pollChannel() }, 0, 60, TimeUnit.SECONDS)
    }

    private fun pollChannel() {
        try {
            val doc = Jsoup.connect("https://t.me/s/smmwayru")
                .userAgent("Mozilla/5.0 (Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                .timeout(15000).get()
            val messages = doc.select(".tgme_widget_message")
            val lastId = prefs.getLong("last_message_id", 0L)
            var newest = lastId
            for (message in messages) {
                val id = message.attr("data-post").substringAfterLast("/", "0").toLongOrNull() ?: continue
                if (id <= lastId) continue
                if (id > newest) newest = id
                val text = message.select(".tgme_widget_message_text").text()
                val code = extractCode(text) ?: continue
                if (prefs.getString("last_code", "") == code) continue
                prefs.edit().putString("last_code", code).apply()
                sendBroadcast(Intent(ACTION_NEW_CODE).setPackage(packageName).putExtra("code", code))
                val n = NotificationCompat.Builder(this, "promo_monitor")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("Найден промокод: $code")
                    .setContentText("Открой приложение и экран активации.")
                    .setAutoCancel(true).build()
                getSystemService(NotificationManager::class.java).notify(2, n)
            }
            if (newest > lastId) prefs.edit().putLong("last_message_id", newest).apply()
        } catch (_: Exception) {
            // Повторная попытка через минуту.
        }
    }

    private fun extractCode(text: String): String? {
        val patterns = listOf(
            "(?i)(?:промокод|promo\\s*code|код)\\s*[:：-]?\\s*([A-Z0-9_-]{4,32})",
            "(?<![A-ZА-Я0-9])([A-Z0-9]{6,16})(?![A-ZА-Я0-9])"
        )
        for (p in patterns) {
            val m = Pattern.compile(p).matcher(text)
            if (m.find()) return m.group(1)?.trim()?.uppercase()
        }
        return null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("promo_monitor", "Промокоды", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(text: String) = NotificationCompat.Builder(this, "promo_monitor")
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("SMMWAY AutoPromo").setContentText(text).setOngoing(true).build()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }

    companion object { const val ACTION_NEW_CODE = "ru.smmway.autopromo.NEW_CODE" }
}
