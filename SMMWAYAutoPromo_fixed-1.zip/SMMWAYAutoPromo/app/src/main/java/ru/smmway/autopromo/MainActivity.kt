package ru.smmway.autopromo

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var web: WebView

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val code = intent?.getStringExtra("code") ?: return
            status.text = "Найден промокод: $code. Проверяю открытую страницу…"
            attemptActivation(code)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 12)
        }
        layout.addView(TextView(this).apply {
            text = "SMMWAY AutoPromo"
            textSize = 24f
        })
        status = TextView(this).apply {
            text = "Запусти мониторинг, войди на SMMWAY и открой экран «Промокод»."
            textSize = 15f
            setPadding(0, 16, 0, 12)
        }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "Запустить мониторинг Telegram"
            setOnClickListener {
                askNotificationPermission()
                ContextCompat.startForegroundService(
                    this@MainActivity,
                    Intent(this@MainActivity, PromoMonitorService::class.java)
                )
                status.text = "Мониторинг запущен: @smmwayru"
            }
        })
        layout.addView(Button(this).apply {
            text = "Остановить мониторинг"
            setOnClickListener {
                stopService(Intent(this@MainActivity, PromoMonitorService::class.java))
                status.text = "Мониторинг остановлен"
            }
        })
        layout.addView(TextView(this).apply {
            text = "Встроенный браузер: войди самостоятельно и открой форму промокода."
        })
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl("https://smmway.ru/")
        }
        layout.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)

        val filter = IntentFilter(PromoMonitorService.ACTION_NEW_CODE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(receiver, filter)
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
    }

    private fun attemptActivation(code: String) {
        val safeCode = JSONObject.quote(code)
        val js = """
            (function() {
              const fields = Array.from(document.querySelectorAll('input'))
                .filter(e => !e.disabled && e.type !== 'hidden' && e.offsetParent !== null);
              const buttons = Array.from(document.querySelectorAll('button, input[type=submit]'))
                .filter(e => !e.disabled && e.offsetParent !== null);
              const target = buttons.find(e =>
                ((e.innerText || e.value || '').trim().toLowerCase()) === 'активировать промокод');
              if (fields.length !== 1 || !target) return 'FORM_NOT_CONFIRMED';
              const f = fields[0];
              f.focus(); f.value = $safeCode;
              f.dispatchEvent(new Event('input', {bubbles:true}));
              f.dispatchEvent(new Event('change', {bubbles:true}));
              target.click();
              return 'SUBMITTED';
            })();
        """.trimIndent()
        web.evaluateJavascript(js) { result ->
            status.text = if (result?.trim('"') == "SUBMITTED")
                "Код отправлен сайту. Проверь результат на странице."
            else "Код найден, но форма не распознана. Открой экран «Промокод»."
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        web.destroy()
        super.onDestroy()
    }
}
